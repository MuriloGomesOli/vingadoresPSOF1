
from model.cadastro import Vingadores
from model.rosto import Rosto as r

    

def main():
    r.menu_vingadores()
        
    

if __name__ == '__main__':
        
        main()